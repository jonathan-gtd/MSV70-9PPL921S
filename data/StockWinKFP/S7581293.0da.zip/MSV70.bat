@echo off
echo ##################################################################
echo #    ______  _                         _            _            #
echo #   (____  \(_)                       ^| ^|          ^| ^|           #
echo #    ____)  )_ ____  ____   ____  ____^| ^|      ____^| ^| _   ___   #
echo #   ^|  __  (^| ^|    \^|    \ / _  )/ ___) ^|     / _  ^| ^|^| \ /___)  #
echo #   ^| ^|__)  ) ^| ^| ^| ^| ^| ^| ( (/ /^| ^|   ^| ^|____( ( ^| ^| ^|_) )___ ^|  #
echo #   ^|______/^|_^|_^|_^|_^|_^|_^|_^|\____)_^|   ^|_______)_^|^|_^|____/(___/   #
echo #                                                                #
echo #         BIMMERLABS.COM - WINKFP TUNING BATCH SCRIPT!           #
echo #         VERSION 0.9.11				         #
echo #                                                                #
echo ##################################################################
echo.
echo By continuing, you agree to the terms and conditions below:
echo.
echo Bimmerlabs.com, its owners, and affiliates, express no warranty
echo for the software and firmware included in this program.
echo You assume all responsibility for the risk that your computer
echo may be damaged, your car made undrivable, and that it might
echo not be possible to recover.
echo.
pause
echo.
echo Bimmerlabs.com makes an effort to test this software, but there is
echo no gaurantee that it will work for your particular car.
echo If you do run into an issue, we will do our best to help - just
echo submit a contact form at www.bimmerlabs.com/contact and we will
echo respond as soon as possible.
echo.
echo If you do not agree to the terms above, close the batch file window.
echo.
echo Otherwise, press enter to accept the terms above and continue.
echo.
pause
echo.
echo Copying Files...
echo.
copy MSV70.ctl C:\EC-APPS\NFS\BIN\MSV70.ctl
if not exist "C:\EC-APPS\NFS\DATA\DEVELOP" mkdir C:\EC-APPS\NFS\DATA\DEVELOP
copy S7581293.0da C:\EC-APPS\NFS\DATA\DEVELOP\S7581293.0da
echo.
echo Flashing...
C:\EC-APPS\NFS\BIN\winkfpt.exe  -batch=MSV70 -run

echo.
echo WinKFP batch file complete - press enter to see programming status.
echo.
pause

type C:\EC-APPS\NFS\BIN\MSV70.prt

pause
